The Decimater is used for reducing the sample-rate of .bdf files, resulting in smaller sized data files.


To Decimate (downsample) .bdf files, do the following:

1) Click start and select the file you want to decimate.
   the original sample rate, number of channels and length will be shown at the left.
2) Select the decimation ratio. (the new sample rate and new bandwidth will be shown)
3) Click on "Start Decimating"
   The decimater will save the decimated file (with extension '-Deci') in the same directory.


